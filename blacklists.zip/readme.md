# Microservicio Blacklist
Este microservicio permite gestionar la lista negra global.
